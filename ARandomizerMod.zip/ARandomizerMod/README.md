# ARandomizerMod
## A randomizer mod that gamifies Maddy480's Extended Variants Mod by adding a score and currency system

A Randomizer Mod adds:
- A weighted version of Maddy's randomizer
- A score that increases as you beat rooms under difficult conditions and collect strawberries
- Currency that can be spent to remove difficult variants
